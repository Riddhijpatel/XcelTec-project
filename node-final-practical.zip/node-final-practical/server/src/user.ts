import * as mongodb from "mongodb";
 
export interface User {

   //country_id,state_id
   
   user_name: string;
   email: string;
   contact_no: number;
   image: any;
   _id?: mongodb.ObjectId;
}