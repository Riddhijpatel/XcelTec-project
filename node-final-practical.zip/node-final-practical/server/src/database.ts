import * as mongodb from "mongodb";
import { User } from "./user";
 
export const collections: {
   users?: mongodb.Collection<User>;
} = {};
 
export async function connectToDatabase(uri: string) {
   const client = new mongodb.MongoClient(uri);
   await client.connect();
 
   const db = client.db("NodeExample");
   await applySchemaValidation(db);
 
   const usersCollection = db.collection<User>("users");
   collections.users = usersCollection;
}
 
// Update our existing collection with JSON schema validation so we know our documents will always match the shape of our User model, even if added elsewhere.
// For more information about schema validation, see this blog series: https://www.mongodb.com/blog/post/json-schema-validation--locking-down-your-model-the-smart-way
async function applySchemaValidation(db: mongodb.Db) {
   const jsonSchema = {
       $jsonSchema: {
           bsonType: "object",
           required: ["user_name", "email", "contact_no"],
           additionalProperties: false,
           properties: {
               _id: {},
               user_name: {
                   bsonType: "string",
                   description: "'user_name' is required and is a string",
               },
               email: {
                   bsonType: "string",
                   description: "'email' is required and is a string",
                   
               },
              contact_no: {
                   bsonType: "number",
                   description: "'contact_no' is required and is a number ",
               },
               image:{}

           },
       },
   };
 
   // Try applying the modification to the collection, if the collection doesn't exist, create it
  await db.command({
       collMod: "users",
       validator: jsonSchema
   }).catch(async (error: mongodb.MongoServerError) => {
       if (error.codeName === 'NamespaceNotFound') {
           await db.createCollection("users", {validator: jsonSchema});
       }
   });
}